Iplsda <-
function(Xtr,Xte,trlevel,televel,ncls=2){

#classical pls_da
cla_plsda=pls.lda(Xtrain=t(Xtr),Ytrain=as.factor(trlevel),Xtest=t(Xte),ncomp=2,nruncv=20)$predclass

cla_plsda_acc<-confusionMatrix(as.factor(cla_plsda), as.factor(televel))[[3]][1]

#proposed pls_da

cc<-poprop<-list()
Calcdist=dist(scale(Xtr),method="euclidean")

HcColumn <- hclust(Calcdist,method="ward.D")
plot(HcColumn)
ncls<-(readline("Please enter number of cluster: "))
hclusters=cutree(HcColumn,ncls)
for (ii in 1:max(hclusters)){
cc[[ii]]<-which(hclusters==ii)
rplsda1=pls.lda(Xtrain=t(Xtr[cc[[ii]],]),Ytrain=as.factor(trlevel),Xtest=t(Xte[cc[[ii]],]),ncomp=2,nruncv=20)
poprop[[ii]]<-rplsda1$pred.lda.out$posterior[,2]
}

newprob=Reduce("+", poprop)/max(hclusters)

a=seq(0.1,0.5,by=0.01)
length(a)
accsim<-NULL
for (pp in 1:length(a)){
plsres<-rep(1,dim(Xte)[2])
plsres[which(newprob>a[pp])]<-2

Resultrplsdar_new <- confusionMatrix(as.factor(plsres), as.factor(televel))
accsim[pp]<-Resultrplsdar_new[[3]][1]
}

maxa=a[which(accsim==max(accsim))]
if (length(maxa)>1){cutoff=maxa[1]}else {cutoff=maxa}

plsresf<-plsres
plsresf[which(newprob>cutoff)]<-2

Resultrplsdar_newf <- confusionMatrix(as.factor(plsresf), as.factor(televel))
prop_plsda_acc<-Resultrplsdar_newf[[3]][1]


return(list(cla_acc=cla_plsda_acc,prop_acc=prop_plsda_acc,pred_level=plsresf,newprob=newprob))
}
