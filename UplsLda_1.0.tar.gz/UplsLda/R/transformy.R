transformy <-
function(y)
{
     y<-as.numeric(y)
     K<-max(y)
     if (K>2)
     {
          Y<-matrix(0,length(y),K)
          for (k in 1:K)
          {
               Y[,k]<-as.numeric(y==k)
               Y[,k]<-Y[,k]-mean(Y[,k])
          }
     }
     else
     {
          Y<-matrix(y-mean(y),length(y),1)
     }
     
     Y
}
