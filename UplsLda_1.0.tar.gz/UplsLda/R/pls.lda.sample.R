pls.lda.sample <-
function(samp,X,Y,ncomp,priors=NULL)
{
errorcv<-numeric(length(ncomp))

for (j in ncomp)
  {
  pls.lda.out<-pls.lda(Xtrain=X[samp,],Ytrain=Y[samp],Xtest=X[-samp,],ncomp=j,nruncv=0,priors=priors)
  errorcv[j]<-sum(pls.lda.out$predclass!=Y[-samp])
  }
errorcv
}
